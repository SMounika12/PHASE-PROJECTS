package com.ms.sorting.in;


public class Orderstatics {
    public static void main(String[] args) {

    	int arr[]= {10,3,5,6,8,2,5};
    	for(int i=0;i<arr.length;i++)
    	{
    		System.out.println("order of matrix;"+arr);
    	}
    	}
}