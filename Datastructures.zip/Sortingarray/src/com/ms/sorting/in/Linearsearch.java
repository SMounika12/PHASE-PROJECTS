package com.ms.sorting.in;

public class Linearsearch {
    public static void main(String[] args) {
        int[] numbers = { 10, 25, 6, 8, 14, 30 };
        int target = 8;

        int index = linearSearch(numbers, target);

        if (index != -1) {
            System.out.println("Element found at index " + index);
        } else {
            System.out.println("Element not found");
        }
    }

    public static int linearSearch(int[] array, int target) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == target) {
                return i;  // Return the index of the target element
            }
        }
        return -1;  // Return -1 if the target element is not found
    }
}
