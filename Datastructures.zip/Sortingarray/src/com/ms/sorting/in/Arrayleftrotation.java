package com.ms.sorting.in;

public class Arrayleftrotation {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        int rotationCount = 2;

        System.out.println("Original Array: ");
        printArray(array);

        rotateArray(array, rotationCount);

        System.out.println("Array after rotation: ");
        printArray(array);
    }

    // Method to rotate the array to the left by the given rotation count
    public static void rotateArray(int[] arr, int rotationCount) {
        int length = arr.length;

        // Perform left rotations
        for (int i = 0; i < rotationCount; i++) {
            int temp = arr[0];
            for (int j = 0; j < length - 1; j++) {
                arr[j] = arr[j + 1];
            }
            arr[length - 1] = temp;
        }
    }

    // Method to print the elements of an array
    public static void printArray(int[] arr) {
        for (int element : arr) {
            System.out.print(element + " ");
        }
        System.out.println();
    }
}