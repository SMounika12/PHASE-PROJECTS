package com.ms.sorting.in;

import java.util.Scanner;

public class Transposematrix {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the number of rows in the matrix: ");
        int rows = input.nextInt();

        System.out.print("Enter the number of columns in the matrix: ");
        int columns = input.nextInt();

        int[][] matrix = readMatrix(rows, columns, input);

        System.out.println("Original Matrix:");
        printMatrix(matrix);

        int[][] transposeMatrix = transpose(matrix);

        System.out.println("Transpose Matrix:");
        printMatrix(transposeMatrix);
    }

    public static int[][] readMatrix(int rows, int columns, Scanner input) {
        int[][] matrix = new int[rows][columns];

        System.out.println("Enter elements of the matrix:");

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                System.out.print("Enter element at position (" + (i + 1) + ", " + (j + 1) + "): ");
                matrix[i][j] = input.nextInt();
            }
        }

        return matrix;
    }

    public static int[][] transpose(int[][] matrix) {
        int rows = matrix.length;
        int columns = matrix[0].length;

        int[][] transposeMatrix = new int[columns][rows];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                transposeMatrix[j][i] = matrix[i][j];
            }
        }

        return transposeMatrix;
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}
