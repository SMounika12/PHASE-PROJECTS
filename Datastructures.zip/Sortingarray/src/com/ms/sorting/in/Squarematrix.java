package com.ms.sorting.in;

import java.util.Scanner;

public class Squarematrix {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the size of the square matrix: ");
        int size = input.nextInt();

        int[][] matrix = generateSquareMatrix(size);

        System.out.println("Square Matrix:");
        printMatrix(matrix);
    }

    public static int[][] generateSquareMatrix(int size) {
        int[][] matrix = new int[size][size];
        int value = 1;

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                matrix[i][j] = value++;
            }
        }

        return matrix;
    }

    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}
